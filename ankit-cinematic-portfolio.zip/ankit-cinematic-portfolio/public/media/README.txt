JET BACKGROUND ASSETS (put your files in this folder)

The site auto-detects these files. If none exist, it shows the animated sky scene.

  jet-loop.mp4     H.264, 8-12 second seamless loop, 1280x720 (or 1920x1080), no audio, about 3-6 MB
  jet-loop.webm    optional, same clip (VP9), smaller on Android Chrome
  jet-poster.jpg   one frame from the clip, 1600 px wide. Shown while loading, with reduced motion, or if video fails.

Make sure you have the right to use the footage commercially:
  - footage you generated with an AI video tool whose terms allow commercial use, or
  - licensed stock footage (read the licence), or
  - footage you filmed/created yourself.
Do not use random YouTube or Google videos.

Encode a clip (if you have ffmpeg):
  ffmpeg -i input.mp4 -an -vf scale=1280:-2 -c:v libx264 -crf 26 -preset slow -movflags +faststart jet-loop.mp4
  ffmpeg -i input.mp4 -an -vf scale=1280:-2 -c:v libvpx-vp9 -crf 34 -b:v 0 jet-loop.webm
  ffmpeg -i input.mp4 -vf "select=eq(n\,60),scale=1600:-2" -frames:v 1 jet-poster.jpg
