OPTIONAL 3D MODEL (used only if there is no jet-loop.mp4)

Put a private-jet model here as:   jet.glb

Requirements: GLB/glTF 2.0, under about 8 MB, textures 2K or smaller, Draco/meshopt compression is fine.
Licence: use a model whose licence allows commercial/website use (for example CC0, CC-BY with credit, or a purchased licence).
Add the required credit to the footer of the site if the licence asks for it.

If the nose does not point the right way, change `yaw` in src/config/site.js (radians; try 1.5708, 3.1416, -1.5708).
