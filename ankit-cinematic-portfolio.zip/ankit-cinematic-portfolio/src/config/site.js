// Single place for your details. Edit here, not in the components.
export const SITE = {
  name: 'Ankit Noneriya',
  title: 'AI & Digital Creative Specialist',
  headline: 'Building Digital Experiences Beyond the Ordinary.',
  intro:
    'I combine AI, web development, and digital creativity to build distinctive online experiences, cinematic content, and modern digital solutions.',
  location: 'Bhopal, Madhya Pradesh, India',
  education: 'B.Sc. 1st year, MVM College, Bhopal',
  email: 'ankitnoneriya616@gmail.com',
  instagram: 'https://www.instagram.com/the.legendankit/',
  youtube: 'https://yt.openinapp.co/mrankitnoneriya',
  portfolio: 'https://ankit-noneriya-portfolio.vercel.app/',
  // Set these through environment variables (see .env.example). Never invent values.
  whatsapp: (import.meta.env.VITE_WHATSAPP_NUMBER || '').replace(/\D/g, ''),
  formEndpoint: import.meta.env.VITE_FORM_ENDPOINT || '',
}

// Jet assets. Drop your files at these paths (see public/media/README.txt).
export const JET = {
  video: { mp4: '/media/jet-loop.mp4', webm: '/media/jet-loop.webm', poster: '/media/jet-poster.jpg' },
  model: {
    path: '/models/jet.glb',
    // Rotate if your model's nose does not point toward +X. Radians.
    yaw: 0,
    // Largest dimension of the model in scene units.
    size: 5,
  },
}

export const SERVICES = [
  { n: '01', title: 'Website Design & Development', text: 'Fast, responsive, carefully crafted websites built with React, modern tooling and thoughtful motion.' },
  { n: '02', title: 'AI-Assisted Creative Solutions', text: 'AI-accelerated workflows for concepts, visuals and content, always shaped by human taste and direction.' },
  { n: '03', title: 'Video Editing', text: 'Clean, rhythmic edits with sound, pacing and color that keep the story moving.' },
  { n: '04', title: 'Voice & Music Editing', text: 'Voice cleanup, mixing and music editing so your audio sounds as good as your visuals look.' },
  { n: '05', title: 'Thumbnail Design', text: 'Bold, readable thumbnails designed to earn the click and represent the content honestly.' },
  { n: '06', title: 'Content Creation', text: 'Ideas, visuals and short-form content built around your brand and your audience.' },
]
