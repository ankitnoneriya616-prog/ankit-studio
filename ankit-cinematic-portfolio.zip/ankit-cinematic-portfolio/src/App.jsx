import { MotionConfig } from 'framer-motion'
import JetBackground from './components/JetBackground'
import Navbar from './components/Navbar'
import Footer from './components/Footer'
import Hero from './sections/Hero'
import About from './sections/About'
import Services from './sections/Services'
import Work from './sections/Work'
import Why from './sections/Why'
import Contact from './sections/Contact'
import FinalCTA from './sections/FinalCTA'

export default function App() {
  return (
    <MotionConfig reducedMotion="user">
      <JetBackground />
      <div className="relative z-10">
        <Navbar />
        <main>
          <Hero />
          <About />
          <Services />
          <Work />
          <Why />
          <Contact />
          <FinalCTA />
        </main>
        <Footer />
      </div>
    </MotionConfig>
  )
}
