import Reveal from '../components/Reveal'
import { SITE } from '../config/site'

// Only real or clearly labelled items. Replace the placeholders with real projects when ready.
const PROJECTS = [
  {
    tag: 'Live project',
    title: 'Personal Portfolio Website',
    text: 'My current portfolio, built with React, Vite, Tailwind CSS and Framer Motion, deployed on Vercel.',
    link: SITE.portfolio,
    cta: 'Visit site',
    tint: 'from-[#1b3556] to-[#0b1626]',
  },
  {
    tag: 'Concept project',
    title: 'Premium Gym Website',
    text: 'A concept design exploring a premium, high-energy one-page website for a fitness brand. Not a client project.',
    tint: 'from-[#4a3a26] to-[#0b1626]',
  },
  {
    tag: 'Placeholder',
    title: 'Video & Thumbnail Showcase',
    text: 'Reserved for selected video edits and thumbnail designs. Replace this card with real work.',
    link: SITE.youtube,
    cta: 'See YouTube',
    tint: 'from-[#2c3440] to-[#0b1626]',
  },
]

export default function Work() {
  return (
    <section id="work" className="bg-midnight/55 px-5 py-24 sm:px-8 sm:py-36">
      <div className="mx-auto max-w-7xl">
        <Reveal>
          <p className="text-xs uppercase tracking-[0.35em] text-champagne">Selected work</p>
          <h2 className="mt-5 max-w-3xl font-display text-4xl leading-tight text-silver sm:text-6xl">
            Projects, honestly labelled.
          </h2>
        </Reveal>

        <div className="mt-14 grid gap-6 lg:grid-cols-3">
          {PROJECTS.map((p, i) => (
            <Reveal key={p.title} delay={i * 0.1}>
              <article className="hairline flex h-full flex-col overflow-hidden rounded-2xl border bg-navy/60">
                <div className={`relative h-48 bg-gradient-to-br ${p.tint} sm:h-56`}>
                  <span className="absolute bottom-4 left-5 font-display text-6xl text-silver/20">0{i + 1}</span>
                </div>
                <div className="flex flex-1 flex-col p-6 sm:p-7">
                  <span className="text-xs uppercase tracking-[0.25em] text-champagne">{p.tag}</span>
                  <h3 className="mt-3 text-xl font-medium text-silver">{p.title}</h3>
                  <p className="mt-3 flex-1 leading-relaxed text-steel">{p.text}</p>
                  {p.link && (
                    <a href={p.link} target="_blank" rel="noopener noreferrer" className="mt-6 inline-flex items-center gap-2 text-sm text-champagne hover:text-silver">
                      {p.cta} <span aria-hidden="true">&rarr;</span>
                    </a>
                  )}
                </div>
              </article>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  )
}
