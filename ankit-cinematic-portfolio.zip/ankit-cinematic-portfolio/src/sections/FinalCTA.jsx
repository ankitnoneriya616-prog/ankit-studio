import Reveal from '../components/Reveal'

export default function FinalCTA() {
  return (
    <section className="flex min-h-[80svh] items-center px-5 py-24 sm:px-8">
      <div className="mx-auto w-full max-w-7xl text-center">
        <Reveal>
          <h2 className="text-shadow mx-auto max-w-4xl font-display text-5xl leading-[1.02] text-silver sm:text-8xl">
            Let&rsquo;s build something that moves.
          </h2>
          <a href="#contact" className="mt-10 inline-block rounded-full bg-champagne px-10 py-4 text-base font-medium text-midnight transition-transform hover:scale-[1.03]">
            Start a Project
          </a>
        </Reveal>
      </div>
    </section>
  )
}
