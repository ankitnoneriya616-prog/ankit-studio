import Reveal from '../components/Reveal'
import { SITE } from '../config/site'

export default function About() {
  return (
    <section id="about" className="bg-midnight/55 px-5 py-24 sm:px-8 sm:py-36">
      <div className="mx-auto grid max-w-7xl gap-12 lg:grid-cols-[1fr_1.2fr] lg:gap-20">
        <Reveal>
          <p className="text-xs uppercase tracking-[0.35em] text-champagne">About</p>
          <h2 className="mt-5 font-display text-4xl leading-tight text-silver sm:text-6xl">
            Where AI, code and storytelling meet.
          </h2>
        </Reveal>
        <Reveal delay={0.12}>
          <div className="space-y-6 text-lg leading-relaxed text-steel">
            <p>
              I&rsquo;m {SITE.name}, a creative professional based in Bhopal working across website development,
              AI-assisted creative solutions, video editing, voice and music editing, thumbnail design and content
              creation.
            </p>
            <p>
              I like projects where technology and storytelling work together: a site that feels alive, a video that
              holds attention, a visual that says the right thing at a glance.
            </p>
            <dl className="hairline grid grid-cols-1 gap-5 border-t pt-6 text-base sm:grid-cols-2">
              <div>
                <dt className="text-xs uppercase tracking-[0.25em] text-champagne">Based in</dt>
                <dd className="mt-1 text-silver">{SITE.location}</dd>
              </div>
              <div>
                <dt className="text-xs uppercase tracking-[0.25em] text-champagne">Studying</dt>
                <dd className="mt-1 text-silver">{SITE.education}</dd>
              </div>
            </dl>
          </div>
        </Reveal>
      </div>
    </section>
  )
}
