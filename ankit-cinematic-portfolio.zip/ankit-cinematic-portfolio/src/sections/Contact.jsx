import { useState } from 'react'
import Reveal from '../components/Reveal'
import { SERVICES, SITE } from '../config/site'

const field =
  'w-full rounded-xl border border-silver/20 bg-midnight/60 px-4 py-3.5 text-base text-silver placeholder:text-steel/70 focus:border-champagne focus:outline-none'

export default function Contact() {
  // status: idle | sending | sent | error | mail
  const [status, setStatus] = useState('idle')

  async function onSubmit(e) {
    e.preventDefault()
    const form = e.currentTarget
    const data = Object.fromEntries(new FormData(form).entries())

    if (SITE.formEndpoint) {
      setStatus('sending')
      try {
        const res = await fetch(SITE.formEndpoint, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
          body: JSON.stringify(data),
        })
        if (!res.ok) throw new Error('bad status')
        setStatus('sent')
        form.reset()
      } catch {
        setStatus('error')
      }
      return
    }

    // No backend configured: be honest and hand the message to the visitor's email app.
    const subject = encodeURIComponent(`Project inquiry: ${data.service || 'General'}`)
    const body = encodeURIComponent(`Name: ${data.name}\nEmail: ${data.email}\nService: ${data.service}\n\n${data.message}`)
    window.location.href = `mailto:${SITE.email}?subject=${subject}&body=${body}`
    setStatus('mail')
  }

  return (
    <section id="contact" className="bg-midnight/60 px-5 py-24 sm:px-8 sm:py-36">
      <div className="mx-auto grid max-w-7xl gap-14 lg:grid-cols-[1fr_1.1fr] lg:gap-20">
        <Reveal>
          <p className="text-xs uppercase tracking-[0.35em] text-champagne">Contact</p>
          <h2 className="mt-5 font-display text-4xl leading-tight text-silver sm:text-6xl">Let&rsquo;s talk about your project.</h2>
          <ul className="mt-10 space-y-4 text-lg">
            <li><a className="text-silver underline decoration-champagne/50 underline-offset-4 hover:decoration-champagne" href={`mailto:${SITE.email}`}>{SITE.email}</a></li>
            <li><a className="text-steel hover:text-silver" href={SITE.instagram} target="_blank" rel="noopener noreferrer">Instagram</a></li>
            <li><a className="text-steel hover:text-silver" href={SITE.youtube} target="_blank" rel="noopener noreferrer">YouTube</a></li>
            {SITE.whatsapp && (
              <li>
                <a className="text-steel hover:text-silver" href={`https://wa.me/${SITE.whatsapp}`} target="_blank" rel="noopener noreferrer">WhatsApp</a>
              </li>
            )}
          </ul>
        </Reveal>

        <Reveal delay={0.12}>
          <form onSubmit={onSubmit} className="space-y-4" noValidate={false}>
            <div>
              <label htmlFor="name" className="mb-2 block text-sm text-steel">Name</label>
              <input id="name" name="name" required autoComplete="name" className={field} placeholder="Your name" />
            </div>
            <div>
              <label htmlFor="email" className="mb-2 block text-sm text-steel">Email</label>
              <input id="email" name="email" type="email" required autoComplete="email" className={field} placeholder="you@example.com" />
            </div>
            <div>
              <label htmlFor="service" className="mb-2 block text-sm text-steel">Service</label>
              <select id="service" name="service" className={field} defaultValue={SERVICES[0].title}>
                {SERVICES.map((s) => (
                  <option key={s.n} value={s.title} className="bg-navy">{s.title}</option>
                ))}
              </select>
            </div>
            <div>
              <label htmlFor="message" className="mb-2 block text-sm text-steel">Project details</label>
              <textarea id="message" name="message" required rows={5} className={field} placeholder="Tell me about your idea, timeline and goals." />
            </div>
            <button
              type="submit"
              disabled={status === 'sending'}
              className="w-full rounded-full bg-champagne px-8 py-4 text-base font-medium text-midnight transition-opacity disabled:opacity-60 sm:w-auto"
            >
              {status === 'sending' ? 'Sending…' : SITE.formEndpoint ? 'Send inquiry' : 'Open in email app'}
            </button>
            <p role="status" aria-live="polite" className="min-h-6 text-sm text-steel">
              {status === 'sent' && 'Thank you. Your inquiry was delivered.'}
              {status === 'error' && `Could not send right now. Please email ${SITE.email} directly.`}
              {status === 'mail' && 'Your email app should open with the message ready to send. Nothing is sent until you press send there.'}
            </p>
          </form>
        </Reveal>
      </div>
    </section>
  )
}
