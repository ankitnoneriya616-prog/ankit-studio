import { motion } from 'framer-motion'
import { SITE } from '../config/site'

const words = SITE.headline.split(' ')

export default function Hero() {
  return (
    <section id="top" className="relative flex min-h-[100svh] items-end px-5 pb-20 pt-32 sm:px-8 sm:pb-28">
      <div className="mx-auto w-full max-w-7xl">
        <motion.p
          initial={{ opacity: 0, y: 14 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.9, delay: 0.2 }}
          className="text-shadow text-xs uppercase tracking-[0.35em] text-champagne sm:text-sm"
        >
          {SITE.title}
        </motion.p>

        <h1 className="text-shadow mt-5 font-display text-[2.9rem] font-medium leading-[0.98] text-silver sm:text-7xl lg:text-[7.5rem]">
          <span className="sr-only">{SITE.name}. </span>
          <span aria-hidden="true" className="block tracking-[0.04em]">
            {'ANKIT NONERIYA'.split(' ').map((w, i) => (
              <motion.span
                key={w}
                className="mr-[0.25em] inline-block"
                initial={{ opacity: 0, y: 40 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 1.1, delay: 0.35 + i * 0.15, ease: [0.22, 1, 0.36, 1] }}
              >
                {w}
              </motion.span>
            ))}
          </span>
        </h1>

        <p className="text-shadow mt-7 max-w-3xl font-display text-2xl italic leading-snug text-silver/95 sm:text-4xl">
          {words.map((w, i) => (
            <motion.span
              key={i}
              className="mr-[0.28em] inline-block"
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.9 + i * 0.07 }}
            >
              {w}
            </motion.span>
          ))}
        </p>

        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1, delay: 1.7 }}
          className="text-shadow mt-6 max-w-xl text-base leading-relaxed text-steel sm:text-lg"
        >
          {SITE.intro}
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.9, delay: 1.9 }}
          className="mt-9 flex flex-col gap-3 sm:flex-row"
        >
          <a href="#work" className="rounded-full bg-champagne px-8 py-4 text-center text-base font-medium text-midnight transition-transform hover:scale-[1.02]">
            Explore My Work
          </a>
          <a href="#contact" className="rounded-full border border-silver/40 px-8 py-4 text-center text-base text-silver transition-colors hover:border-champagne hover:text-champagne">
            Start a Project
          </a>
        </motion.div>
      </div>
    </section>
  )
}
