import Reveal from '../components/Reveal'
import { SERVICES } from '../config/site'

export default function Services() {
  return (
    <section id="services" className="px-5 py-24 sm:px-8 sm:py-36">
      <div className="mx-auto max-w-7xl">
        <Reveal>
          <p className="text-shadow text-xs uppercase tracking-[0.35em] text-champagne">Services</p>
          <h2 className="text-shadow mt-5 max-w-3xl font-display text-4xl leading-tight text-silver sm:text-6xl">
            Six disciplines, one creative workflow.
          </h2>
        </Reveal>

        <ul className="mt-14 grid gap-px overflow-hidden rounded-2xl bg-silver/10 sm:grid-cols-2 lg:grid-cols-3">
          {SERVICES.map((s, i) => (
            <li key={s.n} className="group relative bg-midnight/70 p-7 transition-colors duration-500 hover:bg-navy/90 sm:p-9">
              <Reveal delay={(i % 3) * 0.08}>
                <span className="font-display text-5xl text-champagne/70 transition-colors group-hover:text-champagne">{s.n}</span>
                <h3 className="mt-6 text-xl font-medium text-silver">{s.title}</h3>
                <p className="mt-3 leading-relaxed text-steel">{s.text}</p>
                <span className="mt-7 block h-px w-10 bg-champagne/60 transition-all duration-500 group-hover:w-24" />
              </Reveal>
            </li>
          ))}
        </ul>
      </div>
    </section>
  )
}
