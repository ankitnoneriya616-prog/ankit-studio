import Reveal from '../components/Reveal'

const POINTS = [
  ['Creative thinking', 'Every project starts from your goal, not from a template.'],
  ['AI-assisted workflows', 'AI speeds up the routine work so more time goes into craft and detail.'],
  ['Attention to detail', 'Spacing, pacing, sound and color are treated as part of the message.'],
  ['Visual storytelling', 'Websites, videos and thumbnails that communicate clearly at a glance.'],
  ['Custom solutions', 'Work shaped around your brand and audience, not copied from a pattern.'],
]

export default function Why() {
  return (
    <section className="px-5 py-24 sm:px-8 sm:py-36">
      <div className="mx-auto max-w-7xl">
        <Reveal>
          <p className="text-shadow text-xs uppercase tracking-[0.35em] text-champagne">Why work with me</p>
          <h2 className="text-shadow mt-5 max-w-3xl font-display text-4xl leading-tight text-silver sm:text-6xl">
            Considered work, delivered with care.
          </h2>
        </Reveal>
        <ul className="mt-14 divide-y divide-silver/10 border-y border-silver/10">
          {POINTS.map(([t, d], i) => (
            <li key={t}>
              <Reveal delay={i * 0.05}>
                <div className="grid gap-2 bg-midnight/40 px-1 py-7 sm:grid-cols-[1fr_1.6fr] sm:gap-10 sm:px-4">
                  <h3 className="font-display text-2xl text-silver sm:text-3xl">{t}</h3>
                  <p className="text-lg leading-relaxed text-steel">{d}</p>
                </div>
              </Reveal>
            </li>
          ))}
        </ul>
      </div>
    </section>
  )
}
