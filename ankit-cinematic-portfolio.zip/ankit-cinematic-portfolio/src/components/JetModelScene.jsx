import { Suspense, useEffect, useMemo, useRef } from 'react'
import { Canvas, useFrame } from '@react-three/fiber'
import { Environment, Lightformer, useGLTF } from '@react-three/drei'
import * as THREE from 'three'
import { JET } from '../config/site'

function Jet({ url, mobile }) {
  const { scene } = useGLTF(url)
  const group = useRef()

  // Normalise any model: clone, center and scale to JET.model.size.
  const model = useMemo(() => {
    const clone = scene.clone(true)
    const box = new THREE.Box3().setFromObject(clone)
    const size = box.getSize(new THREE.Vector3())
    const center = box.getCenter(new THREE.Vector3())
    const scale = JET.model.size / Math.max(size.x, size.y, size.z || 1)
    clone.position.sub(center)
    const wrapper = new THREE.Group()
    wrapper.add(clone)
    wrapper.scale.setScalar(scale)
    wrapper.rotation.y = JET.model.yaw
    return wrapper
  }, [scene])

  useFrame(({ clock, camera }) => {
    const t = clock.elapsedTime
    if (group.current) {
      group.current.rotation.z = Math.sin(t * 0.45) * 0.08 // gentle banking
      group.current.rotation.x = Math.sin(t * 0.3) * 0.02
      group.current.position.y = Math.sin(t * 0.6) * 0.12
    }
    // Slow cinematic camera drift around the aircraft
    camera.position.x = Math.sin(t * 0.12) * 2.4
    camera.position.y = 0.7 + Math.sin(t * 0.09) * 0.45
    camera.position.z = 8 + Math.cos(t * 0.1) * 0.6
    camera.lookAt(0, 0, 0)
  })

  return (
    <group ref={group} position={mobile ? [0, 0.9, 0] : [1.6, 0.2, 0]}>
      <primitive object={model} />
    </group>
  )
}

export default function JetModelScene({ onReady }) {
  const mobile = typeof window !== 'undefined' && window.innerWidth < 768

  useEffect(() => {
    onReady && onReady()
  }, [onReady])

  return (
    <Canvas
      dpr={[1, mobile ? 1.25 : 1.75]}
      camera={{ position: [0, 0.7, 8], fov: 32 }}
      gl={{ antialias: true, alpha: true, powerPreference: 'high-performance' }}
      onCreated={({ gl }) => {
        gl.toneMapping = THREE.ACESFilmicToneMapping
        gl.toneMappingExposure = 1.05
      }}
      style={{ position: 'absolute', inset: 0 }}
    >
      <hemisphereLight args={['#9db8da', '#1a2433', 0.6]} />
      <directionalLight position={[6, 5, 3]} intensity={2.2} color="#ffe2b8" />
      <directionalLight position={[-5, 2, -3]} intensity={0.8} color="#6f9bd1" />
      {/* Self-contained reflections (no external HDR download) */}
      <Environment resolution={256}>
        <Lightformer form="rect" intensity={2.4} color="#ffd9a8" position={[5, 3, -5]} scale={[10, 4, 1]} />
        <Lightformer form="rect" intensity={1.6} color="#7aa6dc" position={[-6, 2, 4]} scale={[8, 3, 1]} />
        <Lightformer form="rect" intensity={0.7} color="#ffffff" position={[0, 6, 0]} rotation-x={Math.PI / 2} scale={[12, 12, 1]} />
      </Environment>
      <Suspense fallback={null}>
        <Jet url={JET.model.path} mobile={mobile} />
      </Suspense>
    </Canvas>
  )
}
