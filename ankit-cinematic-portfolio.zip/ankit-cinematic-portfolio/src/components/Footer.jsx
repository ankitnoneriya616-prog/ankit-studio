import { SITE } from '../config/site'

export default function Footer() {
  return (
    <footer className="hairline border-t bg-midnight/85 px-5 py-10 sm:px-8" style={{ paddingBottom: 'max(2.5rem, env(safe-area-inset-bottom))' }}>
      <div className="mx-auto flex max-w-7xl flex-col gap-6 text-sm text-steel sm:flex-row sm:items-center sm:justify-between">
        <p>&copy; {new Date().getFullYear()} {SITE.name}. {SITE.location}.</p>
        <ul className="flex gap-6">
          <li><a className="hover:text-silver" href={SITE.instagram} target="_blank" rel="noopener noreferrer">Instagram</a></li>
          <li><a className="hover:text-silver" href={SITE.youtube} target="_blank" rel="noopener noreferrer">YouTube</a></li>
          <li><a className="hover:text-silver" href={`mailto:${SITE.email}`}>Email</a></li>
        </ul>
      </div>
    </footer>
  )
}
