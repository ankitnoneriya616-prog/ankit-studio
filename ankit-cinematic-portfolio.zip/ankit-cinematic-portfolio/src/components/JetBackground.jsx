import { Component, lazy, Suspense, useEffect, useState } from 'react'
import SkyFallback from './SkyFallback'
import { JET } from '../config/site'

const JetModelScene = lazy(() => import('./JetModelScene'))

// SPA hosts answer missing files with index.html (200). Check the content type to be sure the asset is real.
async function assetExists(url, accept) {
  try {
    const res = await fetch(url, { method: 'HEAD', cache: 'no-store' })
    if (!res.ok) return false
    const type = (res.headers.get('content-type') || '').toLowerCase()
    return !type.includes('text/html') && accept(type)
  } catch {
    return false
  }
}

function hasWebGL() {
  try {
    const c = document.createElement('canvas')
    return !!(c.getContext('webgl2') || c.getContext('webgl'))
  } catch {
    return false
  }
}

class Boundary extends Component {
  state = { failed: false }
  static getDerivedStateFromError() { return { failed: true } }
  componentDidCatch() { this.props.onFail && this.props.onFail() }
  render() { return this.state.failed ? null : this.props.children }
}

export default function JetBackground() {
  // mode: 'sky' | 'video' | 'model' | 'poster'
  const [mode, setMode] = useState('sky')
  const [poster, setPoster] = useState(false)
  const [ready, setReady] = useState(false)
  const reduced = typeof window !== 'undefined' && window.matchMedia('(prefers-reduced-motion: reduce)').matches

  useEffect(() => {
    let cancelled = false
    ;(async () => {
      const lowPower =
        (navigator.deviceMemory && navigator.deviceMemory <= 2) ||
        (navigator.hardwareConcurrency && navigator.hardwareConcurrency <= 2) ||
        (navigator.connection && navigator.connection.saveData)

      const hasPoster = await assetExists(JET.video.poster, (t) => t.startsWith('image/'))
      if (cancelled) return
      setPoster(hasPoster)

      if (reduced) {
        if (hasPoster) setMode('poster')
        return
      }
      if (await assetExists(JET.video.mp4, (t) => t.startsWith('video/'))) {
        if (!cancelled) setMode('video')
        return
      }
      if (!lowPower && hasWebGL() && (await assetExists(JET.model.path, () => true))) {
        if (!cancelled) setMode('model')
      }
    })()
    return () => { cancelled = true }
  }, [reduced])

  const fallback = () => setMode(poster ? 'poster' : 'sky')

  return (
    <div className="fixed inset-0 z-0 pointer-events-none" aria-hidden="true">
      <SkyFallback animate={mode === 'sky' && !reduced} />

      {mode === 'poster' && (
        <img src={JET.video.poster} alt="" className="absolute inset-0 h-full w-full object-cover" />
      )}

      {mode === 'video' && (
        <video
          className="absolute inset-0 h-full w-full object-cover transition-opacity duration-1000"
          style={{ opacity: ready ? 1 : 0 }}
          autoPlay
          muted
          loop
          playsInline
          preload="auto"
          poster={poster ? JET.video.poster : undefined}
          onCanPlay={() => setReady(true)}
          onError={fallback}
        >
          <source src={JET.video.webm} type="video/webm" />
          <source src={JET.video.mp4} type="video/mp4" onError={fallback} />
        </video>
      )}

      {mode === 'model' && (
        <Boundary onFail={fallback}>
          <Suspense fallback={null}>
            <JetModelScene onReady={() => setReady(true)} />
          </Suspense>
        </Boundary>
      )}

      {/* Readability: darken top and bottom, keep the middle open so the jet stays visible */}
      <div
        className="absolute inset-0"
        style={{
          background:
            'linear-gradient(180deg, rgba(5,10,19,0.72) 0%, rgba(5,10,19,0.25) 32%, rgba(5,10,19,0.35) 62%, rgba(5,10,19,0.82) 100%)',
        }}
      />
      <div className="grain" />
    </div>
  )
}
