import { useEffect, useState } from 'react'

// Seamlessly tiling fractal noise -> soft cloud texture, generated once on a small canvas.
function makeCloudTexture(seed, w = 512, h = 192) {
  const canvas = document.createElement('canvas')
  canvas.width = w
  canvas.height = h
  const ctx = canvas.getContext('2d')
  const img = ctx.createImageData(w, h)

  let s = seed
  const rand = () => ((s = (s * 16807) % 2147483647) / 2147483647)
  const octaves = [
    { gx: 4, gy: 2, a: 0.5 },
    { gx: 8, gy: 4, a: 0.28 },
    { gx: 16, gy: 8, a: 0.14 },
    { gx: 32, gy: 16, a: 0.08 },
  ].map((o) => ({ ...o, grid: Array.from({ length: o.gx * o.gy }, rand) }))

  const smooth = (t) => t * t * (3 - 2 * t)
  const sample = (o, x, y) => {
    const fx = (x / w) * o.gx
    const fy = (y / h) * o.gy
    const x0 = Math.floor(fx), y0 = Math.floor(fy)
    const tx = smooth(fx - x0), ty = smooth(fy - y0)
    const g = (ix, iy) => o.grid[(((iy % o.gy) + o.gy) % o.gy) * o.gx + (((ix % o.gx) + o.gx) % o.gx)]
    const a = g(x0, y0) + (g(x0 + 1, y0) - g(x0, y0)) * tx
    const b = g(x0, y0 + 1) + (g(x0 + 1, y0 + 1) - g(x0, y0 + 1)) * tx
    return a + (b - a) * ty
  }

  for (let y = 0; y < h; y++) {
    const fade = Math.sin((y / h) * Math.PI) // thin out toward top/bottom edges
    for (let x = 0; x < w; x++) {
      let v = 0
      for (const o of octaves) v += sample(o, x, y) * o.a
      const alpha = Math.max(0, (v - 0.42) * 2.6) * fade
      const i = (y * w + x) * 4
      img.data[i] = 214
      img.data[i + 1] = 224
      img.data[i + 2] = 238
      img.data[i + 3] = Math.min(255, alpha * 255)
    }
  }
  ctx.putImageData(img, 0, 0)
  return canvas.toDataURL('image/png')
}

export default function SkyFallback({ animate = true }) {
  const [tex, setTex] = useState(null)

  useEffect(() => {
    setTex({ a: makeCloudTexture(1337), b: makeCloudTexture(9001) })
  }, [])

  const cls = (extra) => `cloud-layer ${animate ? '' : 'static'} ${extra}`

  return (
    <div className="absolute inset-0 overflow-hidden" aria-hidden="true">
      <div
        className="absolute inset-0"
        style={{
          background:
            'linear-gradient(180deg,#040a14 0%,#0a1d36 38%,#254566 66%,#7d8da1 86%,#c9b693 100%)',
        }}
      />
      <div
        className="absolute inset-x-0 bottom-0 h-[60%]"
        style={{ background: 'radial-gradient(60% 70% at 70% 100%, rgba(255,214,160,0.38), transparent 70%)' }}
      />
      {tex && (
        <>
          <div
            className={cls('')}
            style={{ top: '8%', height: '34%', backgroundImage: `url(${tex.a})`, backgroundSize: '50% 100%', opacity: 0.45, animationDuration: '240s' }}
          />
          <div
            className={cls('')}
            style={{ top: '34%', height: '40%', backgroundImage: `url(${tex.b})`, backgroundSize: '50% 100%', opacity: 0.6, animationDuration: '150s' }}
          />
          <div
            className={cls('')}
            style={{ top: '58%', height: '46%', backgroundImage: `url(${tex.a})`, backgroundSize: '50% 100%', opacity: 0.8, animationDuration: '90s' }}
          />
        </>
      )}
    </div>
  )
}
